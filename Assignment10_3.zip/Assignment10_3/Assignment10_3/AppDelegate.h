//
//  AppDelegate.h
//  Assignment10_3
//
//  Created by Trung Đức on 4/22/16.
//  Copyright © 2016 Trung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


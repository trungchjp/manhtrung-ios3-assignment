//
//  AppDelegate.h
//  Assignment10_2
//
//  Created by Trung Đức on 4/22/16.
//  Copyright © 2016 Manh Trung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  ViewController.m
//  Assignment10_2
//
//  Created by Trung Đức on 4/22/16.
//  Copyright © 2016 Manh Trung. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor lightGrayColor];
    _image.image = [UIImage imageNamed:@"1.jpg"];
    
    _image.frame = CGRectMake(0, 0, 300, 300);
    _image.center = _image.superview.center;
    
    _image.contentMode = UIViewContentModeScaleAspectFill;
    _image.layer.cornerRadius = _image.frame.size.width/2;
    _image.layer.masksToBounds = YES;
    _image.layer.borderColor = [UIColor blueColor].CGColor;
    _image.layer.borderWidth = 2.0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
    UITouch *touch = [[event allTouches] anyObject];
    CGPoint touchPoint = [touch locationInView:self.view];
    NSLog(@"Touched at: %f, %f", _image.frame.origin.x,  _image.frame.origin.y);
    _image.center = touchPoint;
}


@end
